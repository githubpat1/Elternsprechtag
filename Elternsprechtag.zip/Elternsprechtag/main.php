<!DOCTYPE html>
<html lang="de">

<!-- Head------------------------------------------------------ -->
  <head>
    <meta charset="utf-8">
    <title>BBS-Syke Elternsrpechtag</title>
    <link rel="stylesheet" href="stylee.css" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  </head>
<!-- Menü Leiste plus Logo------------------------------------------------------ -->
  <body>
      <section id="menubar">
        <ul>
          <li><a href="https://www.bbs-syke.de/"><img src="Bilder\bbs-syke_logo.png"/></a></li>  
          <li><img src="Bilder\menubutton.png"/></li>
        </ul>
      </section>
<!-- Header------------------------------------------------------ -->
      <header id="header">
        <h1>Elternsprechtag Termin Planer</h1>
      </header>
<!-- Navigations Leiste------------------------------------------------------ -->
      <nav class="nav">
        <ul>
          <li><a href="https://www.bbs-syke.de/" class="active">Startseite</a></li>
          <li><a href="https://www.bbs-syke.de/portal/kontakt.html?titel=Kontakt">Kontakt</a></li>
        </ul>
      </nav>
<!-- Main------------------------------------------------------ -->
    <main>
      <article>
        <h2>Lorem ipsum</h2>
        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
      </article>
    </main>
<!-- Footer------------------------------------------------------ -->
    <footer>
      <ul>
        <li><a href="https://www.bbs-syke.de/portal/kontakt.html">Kontakt</li>
        <li><a href="https://www.bbs-syke.de/portal/seiten/datenschutz-1002-2186.html">Datenschutz</li>
        <li><a href="https://www.bbs-syke.de/portal/seiten/impressum-1001-2186.html">Impressum</li>
      </ul>
    </footer>
  </body>
</html>
